<?php
use Illuminate\Support\Facades\Route;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/','MyController@home');
Route::get('/login','MyController@login');
Route::get('/aboutus','MyController@aboutus');
Route::get('/discussion','MyController@discussion');
Route::get('/contactus','MyController@contactus');
Route::get('/findpet','MyController@findpet');
Route::get('/regis','MyController@regis');
Route::get('/regis','MyController@regis');
Route::post('/login-post', 'MyController@loginPost');
Route::get('/template', function (){
   return view('template');
});

Route::get('/', function (){
    return view('home2');
});

Route::get('/dis2', function (){
   return view('dis2');
});

Route::post('/regis', 'MyController@registration');

Route::get('/regispet', function (){
   return view('regispet');
});
Route::post('/regispet', 'MyController@regisPet');