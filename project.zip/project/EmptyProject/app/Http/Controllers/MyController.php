<?php

namespace App\Http\Controllers;

use App\Member;
use App\Pets;
use App\Role;
use App\User;
use App\UserRole;
use App\Users;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Validator;

class MyController extends Controller
{
    //public function welcome(){
    //    return view ('welcome');
    //}
    public function home(){
        return view('home');
    }
    public function login(){
        return view('login');
    }
    public function aboutus(){
        return view('aboutus');
    }
    public function discussion(){
        return view('discussion');
    }
    public function contactus(){
        return view('contactus');
    }
    public function findpet(){
        return view('findpet');
    }
    public function regis(){
        return view('regis');
    }

    public function registration(Request $request){
        $validasi= Validator::make($request->all(),[
            'username' => 'require|max:30',
            'email' => 'require|max:30',
            'password' => 'require|min:8',
            'confirm-password' => 'require|password',
        ]);

        $insert = new Member();
        $insert->name = $request->username;
        $insert->email = $request->email;
        $insert->password = $request->password;
        $insert->save();

        return Redirect('/');
    }

    public function regisPet(Request $request)
    {
        $validasi= Validator::make($request->all(),[
            'name' => 'require|max:30',
            'email' => 'require|max:30',
            'gender' => 'require',
            'type' => 'require',
            'photo' => 'require',
        ]);

        $name = "";
        if ($request->hasFile('photo')){
            $image = $request->file('photo');
            $name = time() . '.' . $image->getClientOriginalName();
            $dest = 'photo/';
            $image->move($dest,$name);
        }

        $insert = new Pets();
        $insert->name = $request->name;
        $insert->email = $request->email;
        $insert->gender = $request->gender;
        $insert->type = $request->type;
        $insert->photo = $name;
        $insert->save();

        return Redirect('/');
    }

    public function loginPost(Request $request)
    {
        $email = $request->email;
        $password = $request->password;

        $credential = [
            'email' => $email,
            'password' => $password,
        ];

        if (Auth::attempt($credential)) {
            return redirect('/home2');
        } else {
            return redirect('/login')
                ->with('alert', 'Invalid Email or Password');
        }

//        $email = $request->input('email');
//        $password = $request->input('password');
//
//        $checkLogin = DB::table('members')->where(['email'=>$email,'password'=>$password])->get();
//        if(count($checkLogin)>0){
//            return redirect('/');
//        }else{
//            return redirect('/login')
//                ->with('alert','Invalid Email or Password');
//        }
    }
}
