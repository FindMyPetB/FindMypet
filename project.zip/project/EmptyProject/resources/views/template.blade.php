<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" href="/css/footer.css">
    <link rel="stylesheet" href="/css/navbar.css">
    <link rel="stylesheet" type="text/css" href="style.css">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
<header>
    <nav class="navbar navbar-inverse">
        <div class="container-fluid">
            <div class="navbar-header">c
                <a class="navbar-brand" href="/">FindMyPet</a>
            </div>

            <form class="navbar-form navbar-left" action="/action_page.php">
                <div class="input-group">
                    <input type="text" class="form-control" placeholder="Search something here" name="Search">
                    <div class="input-group-btn">
                        <button class="btn btn-default" type="submit">
                            <i class="glyphicon glyphicon-search"></i>
                        </button>
                    </div>
                </div>
            </form>

            <ul class="nav navbar-nav">
                <li class="Find"><a href="/findpet">Find</a></li>
                <li class="Find"><a href="/aboutus">About</a></li>
                <li class="Find"><a href="/contactus">Contact Us</a></li>
                <li class="regis"><a href="/regis">Register</a></li>
                <li class="login"><a href="/login">Login</a></li>
            </ul>
        </div>
    </nav>
</header>


@yield('content')


{{--<footer id="copyright" class="row">--}}
    {{--<div class="container text-center">--}}
        {{--<h5>Copyright&copy; 2018</h5>--}}
    {{--</div>--}}
{{--</footer>--}}

</body>
</html>
