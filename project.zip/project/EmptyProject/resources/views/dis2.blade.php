@extends('template')


@section('content')
    <div class="bar-jenis">
        <a href="home.html"><img src="photo/images/dll_03.gif" align="left" style="padding-top: 25px; padding-left: 5px;"></a>
        <a href="discussion.html"><img src="photo/diss (1).png" height="100px" width="100px"></a>
        <a href="findPet.html"><img src="photo/diss (2).png" height="100px" width="100px"></a>
        <a href="findStray.html"><img src="photo/diss (3).png" height="100px" width="100px"></a>
        <a href="findMate.html"><img src="photo/diss (4).png" height="100px" width="100px"></a>
        <a href="donate.html"><img src="photo/diss (5).png" height="100px" width="100px"></a>
        <a href="login.html"><img src="photo/Login.png" align="right" style="padding-top: 25px; padding-left: 5px;"></a>
    </div>
    <div class="discuss-css">
        <div id="photographer1">
            <div class="photo-photographer">
                <img src="photo/foto/cat.png"
                     style="float: left;margin-right: 20px;margin-bottom: 5px;" height="173" width="280">
            </div>
            <div class="biodata-nama">
                All about Cats
            </div>
            <div class="biodata-info">
                Every topic about Cats is here
            </div>
            <div class="biodata-grade">
            </div>
        </div>
    </div>
    <div class="discuss-css">
        <a href="dogdiss.html" style="text-decoration: none">
            <div id="photographer2">
                <div class="photo-photographer">
                    <img src="photo/foto/dog.png" style="float: left;margin-right: 20px;margin-bottom: 5px;" height="173" width="280">
                </div>
                <div class="biodata-nama">
                    All about Dogs
                </div>
                <div class="biodata-info">
                    Every topic about Dogs is here
                </div>
            </div>
        </a>
    </div>
    <div class="discuss-css">
        <div id="photographer3">
            <div class="photo-photographer">
                <img src="photo/foto/bug.png"
                     style="float: left;margin-right: 20px;margin-bottom: 5px;" height="173" width="280">
            </div>
            <div class="biodata-nama">
                All about Insects
            </div>
            <div class="biodata-info">
                Every topic about Insects is here
            </div>
        </div>
    </div>
    <div class="discuss-css">
        <div id="photographer4">
            <div class="photo-photographer">
                <img src="photo/foto/animal.png"
                     style="float: left;margin-right: 20px;margin-bottom: 5px;" height="173" width="280">
            </div>
            <div class="biodata-nama">
                All about others
            </div>
            <div class="biodata-info">
                Every topic about Others is here
            </div>
        </div>
    </div>
    <div class="discuss-css">
        <div id="photographer5">
            <div class="photo-photographer">
                <img src="photo/foto/bird.png"
                     style="float: left;margin-right: 20px;margin-bottom: 5px;" height="173" width="280">
            </div>
            <div class="biodata-nama">
                All about Birds
            </div>
            <div class="biodata-info">
                Every topic about Birds is here
            </div>
        </div>
    </div>
@endsection