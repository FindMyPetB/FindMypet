@extends('template')

@section('content')
    <div class="container">
        <form action="/regispet" method="post" enctype="multipart/from-data">
            {{csrf_field()}}
            <div class="form-group">
                <label for="name">Name</label>
                <input type="text" class="form-control" id="name"  name="name">
            </div>

            <div class="form-group">
                <label for="email">Email Owner</label>
                <input type="text" class="form-control" id="email"  name="email">
            </div>
            <div class="form-group">
                <label for="gender">Gender</label>
                <select class="form-control" id="gender" name="gender">
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                </select>
            </div>
            <div class="form-group">
                <label for="type">Type Pet</label>
                <select class="form-control" id="type" name="type">
                    <option value="Dog">Dog</option>
                    <option value="Cat">Cat</option>
                </select>
            </div>
            <div class="form-group">
                <label for="photo">Photo</label>
                <input type="file" class="form-control" id="photo" name="photo">
            </div>
            <button type="submit">Register Pet</button>
        </form>
    </div>
@endsection