@extends('template')


<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<link rel="stylesheet" type="text/css" href="style.css">

@section('content')
    <body style='background-color:powderblue'>
<div class="discuss-css">
    <div id="photographer1">
        <div class="photo-photographer">
            <img src="photo/foto/cat.png"
                 style="float: left;margin-right: 20px;margin-bottom: 5px;" height="173" width="280">
        </div>
        <div class="biodata-nama">
            All about Cats
        </div>
        <div class="biodata-info">
            Every topic about Cats is here
        </div>
        <div class="biodata-grade">
        </div>
    </div>
</div>
<div class="discuss-css">
    <a href="dogdiss.html" style="text-decoration: none">
        <div id="photographer2">
            <div class="photo-photographer">
                <img src="photo/foto/dog.png" style="float: left;margin-right: 20px;margin-bottom: 5px;" height="173" width="280">
            </div>
            <div class="biodata-nama">
                All about Dogs
            </div>
            <div class="biodata-info">
                Every topic about Dogs is here
            </div>
        </div>
    </a>
</div>
<div class="discuss-css">
    <div id="photographer3">
        <div class="photo-photographer">
            <img src="photo/foto/bug.png"
                 style="float: left;margin-right: 20px;margin-bottom: 5px;" height="173" width="280">
        </div>
        <div class="biodata-nama">
            All about Insects
        </div>
        <div class="biodata-info">
            Every topic about Insects is here
        </div>
    </div>
</div>
<div class="discuss-css">
    <div id="photographer4">
        <div class="photo-photographer">
            <img src="photo/foto/animal.png"
                 style="float: left;margin-right: 20px;margin-bottom: 5px;" height="173" width="280">
        </div>
        <div class="biodata-nama">
            All about others
        </div>
        <div class="biodata-info">
            Every topic about Others is here
        </div>
    </div>
</div>
<div class="discuss-css">
    <div id="photographer5">
        <div class="photo-photographer">
            <img src="photo/foto/bird.png"
                 style="float: left;margin-right: 20px;margin-bottom: 5px;" height="173" width="280">
        </div>
        <div class="biodata-nama">
            All about Birds
        </div>
        <div class="biodata-info">
            Every topic about Birds is here
        </div>
    </div>
</div>
@endsection