<!DOCTYPE html>
<html>
<head>
    <title>Find My Pet</title>
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <link rel="stylesheet" type="text/css" href="style.css">
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" href="/css/footer.css">
    <link rel="stylesheet" href="/css/navbar.css">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body style="background-color: powderblue;">
<header>
    <nav class="navbar navbar-inverse">
        <div class="container-fluid">
            <div class="navbar-header">
                <a class="navbar-brand" href="/">FindMyPet</a>
            </div>

            <form class="navbar-form navbar-left" action="/action_page.php">
                <div class="input-group">
                    <input type="text" class="form-control" placeholder="Search something here" name="Search">
                    <div class="input-group-btn">
                        <button class="btn btn-default" type="submit">
                            <i class="glyphicon glyphicon-search"></i>
                        </button>
                    </div>
                </div>
            </form>

            <ul class="nav navbar-nav">

                <li class="Find"><a href="findPet.html">Find</a></li>
                <li class="Find"><a href="aboutus.html">About</a></li>
                <li class="Find"><a href="contactus.html">Contact Us</a></li>

                <li class="regis"><a href="Login.html">Register</a></li>
                <li class="login" ><a href="Login.html">Login</a></li>
            </ul>
        </div>
    </nav>
</header>
<div class="content">
    <div class="slider-home">
        <figure>
            <img src="https://r.hswstatic.com/w_907/gif/animal-stereotype-1.jpg" style="width: 683px; height: 400px">
            <img src="https://r.hswstatic.com/w_907/gif/animal-stereotype-1.jpg" style="width: 683px; height: 400px">
            <img src="https://r.hswstatic.com/w_907/gif/animal-stereotype-1.jpg" style="width: 683px; height: 400px">
            <img src="https://r.hswstatic.com/w_907/gif/animal-stereotype-1.jpg" style="width: 683px; height:400px">
            <img src="https://r.hswstatic.com/w_907/gif/animal-stereotype-1.jpg" style="width: 683px; height: 400px">
        </figure>
    </div>
</div>
<section class="our-webcoderskull padding-lg">
    <div class="container">
        <div class="row heading heading-icon">
            <h2 style="color: black;">Missing</h2>
        </div>
        <ul class="row">
            <li class="col-12 col-md-6 col-lg-3">
                <div class="cnt-block equal-hight" style="height: 349px;">
                    <figure><img src="http://www.webcoderskull.com/img/team4.png" class="img-responsive" alt=""></figure>
                    <h3><a href="petinfo.html">Nama Hewan</a></h3>
                    <p>Keterangan Umum</p>

                </div>
            </li>
            <li class="col-12 col-md-6 col-lg-3">
                <div class="cnt-block equal-hight" style="height: 349px;">
                    <figure><img src="http://www.webcoderskull.com/img/team1.png" class="img-responsive" alt=""></figure>
                    <h3><a href="petinfo.html">Nama Hewan</a></h3>
                    <p>Keterangan Umum</p>

                </div>
            </li>
            <li class="col-12 col-md-6 col-lg-3">
                <div class="cnt-block equal-hight" style="height: 349px;">
                    <figure><img src="http://www.webcoderskull.com/img/team4.png" class="img-responsive" alt=""></figure>
                    <h3><a href="petinfo.html">Nama Hewan</a></h3>
                    <p>Keterangan umum</p>

                </div>
            </li>
            <li class="col-12 col-md-6 col-lg-3">
                <div class="cnt-block equal-hight" style="height: 349px;">
                    <figure><img src="http://www.webcoderskull.com/img/team2.png" class="img-responsive" alt=""></figure>
                    <h3><a href="petinfo.html">Nama Hewan</a></h3>
                    <p>Keterangan Umum</p>

                </div>
            </li>
        </ul>
    </div>
</section>
<div class="logoHome">
    <img src="photo/Find My Pet.png" style="height: 100px; width: 100px;">
</div>
</body>
</html>