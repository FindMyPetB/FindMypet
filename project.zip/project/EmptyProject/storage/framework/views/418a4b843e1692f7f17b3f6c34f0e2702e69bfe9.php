<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<link rel="stylesheet" type="text/css" href="style.css">

<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="slider-home">
            
                
                
                
                
                
            
        </div>
    </div>
    <section class="our-webcoderskull padding-lg">
        <div class="container">
            <body style='background-color:powderblue'>
            <div class="row heading heading-icon">
                <h2 style="color: black;">Missing</h2>
            </div>
            <ul class="row">
                <li class="col-12 col-md-6 col-lg-3">
                    <div class="cnt-block equal-hight" style="height: 349px;">
                        <figure><img src="http://www.webcoderskull.com/img/team4.png" class="img-responsive" alt=""></figure>
                        <h3><a href="petinfo.html">Nama Hewan</a></h3>
                        <p>Keterangan Umum</p>

                    </div>
                </li>
                <li class="col-12 col-md-6 col-lg-3">
                    <div class="cnt-block equal-hight" style="height: 349px;">
                        <figure><img src="http://www.webcoderskull.com/img/team1.png" class="img-responsive" alt=""></figure>
                        <h3><a href="petinfo.html">Nama Hewan</a></h3>
                        <p>Keterangan Umum</p>

                    </div>
                </li>
                <li class="col-12 col-md-6 col-lg-3">
                    <div class="cnt-block equal-hight" style="height: 349px;">
                        <figure><img src="http://www.webcoderskull.com/img/team4.png" class="img-responsive" alt=""></figure>
                        <h3><a href="petinfo.html">Nama Hewan</a></h3>
                        <p>Keterangan umum</p>

                    </div>
                </li>
                <li class="col-12 col-md-6 col-lg-3">
                    <div class="cnt-block equal-hight" style="height: 349px;">
                        <figure><img src="http://www.webcoderskull.com/img/team2.png" class="img-responsive" alt=""></figure>
                        <h3><a href="petinfo.html">Nama Hewan</a></h3>
                        <p>Keterangan Umum</p>

                    </div>
                </li>
            </ul>
        </div>
    </section>
    <div class="logoHome" align="center">
        <img src="photo/Find My Pet.png" style="height: 100px; width: 100px;">
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>